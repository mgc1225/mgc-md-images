---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
---
